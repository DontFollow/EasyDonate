<?php include 'install_files/php/boot.php'; ?><!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width">
        <title>EasyDonate - Установка</title>
        <link type="image/png" href="install_files/images/easydonate.png" rel="icon">

        <!-- Styles -->
        <link href="install_files/css/vendor.css" rel="stylesheet">
        <link href="install_files/css/layout.css" rel="stylesheet">
        <link href="install_files/css/controls.css" rel="stylesheet">
        <link href="install_files/css/animations.css" rel="stylesheet">
        <link href="install_files/css/fonts.css" rel="stylesheet">
        <link href="install_files/css/style.css" rel="stylesheet">

        <!-- Base URL -->
        <?php if (!isset($fatalError)): ?>
            <script>
            <!--
                installerBaseUrl = '<?= $installer->getBaseUrl() ?>';
            // -->
            </script>
        <?php endif ?>
    </head>
    <body class="js">

        <div id="wrap">

            <!-- Header -->
            <header>
                <div class="container" id="containerHeader"></div>

                <!-- Title -->
                <section class="title">
                    <div class="container" id="containerTitle"></div>
                </section>

            </header>

            <!-- Body -->
            <section class="body">
                <?php if (isset($fatalError)): ?>
                    <div class="container">
                        <div class="callout callout-danger"><?= $fatalError ?></div>
                    </div>
                <?php else: ?>
                    <div class="container" id="containerBody"></div>
                <?php endif ?>
            </section>

        </div>

        <!-- Footer -->
        <footer>
            <div class="container" id="containerFooter"></div>
        </footer>

        <?php if (!isset($fatalError)): ?>

            <!-- Render Partials -->
            <?php
                $partialList = [
                    'header',
                    'title',
                    'footer',
                    'check',
                    'check/fail',
                    'config',
                    'config/mysql',
                    'config/pgsql',
                    'config/sqlite',
                    'config/sqlsrv',
                    'config/fail',
                    'config/database',
                    'config/license',
                    'config/admin',
                    'config/advanced',
                    'starter',
                    'themes',
                    'themes/theme',
                    'project',
                    'project/project',
                    'project/plugins',
                    'project/plugin',
                    'project/themes',
                    'project/theme',
                    'project/suggestion',
                    'project/fail',
                    'progress',
                    'progress/fail',
                    'complete'
                ];
            ?>

            <?php foreach ($partialList as $file): ?>
                <script type="text/template" data-partial="<?= $file ?>">
                    <?php include 'install_files/partials/'.$file.'.htm'; ?>
                </script>
            <?php endforeach ?>

            <!-- Scripts -->
            <script src="install_files/js/vendor.js"></script>
            <script src="install_files/js/app.js"></script>
            <script src="install_files/js/check.js"></script>
            <script src="install_files/js/config.js"></script>
            <script src="install_files/js/starter.js"></script>
            <script src="install_files/js/themes.js"></script>
            <script src="install_files/js/project.js"></script>
            <script src="install_files/js/progress.js"></script>
            <script src="install_files/js/complete.js"></script>

            <!-- Bespoke Properties -->
            <script>
                /*
                 * Checker Page
                 */
                Installer.Pages.systemCheck.title = 'Проверка системы'
                Installer.Pages.systemCheck.nextButton = 'Продолжить'

                Installer.Pages.systemCheck.requirements = [
                    { code: 'phpVersion', label: 'PHP версия 7.0 - 7.2' },
                    { code: 'curlLibrary', label: 'cURL PHP Расширение' },
                    { code: 'liveConnection', label: 'Проверка подключения к серверу' },
                    { code: 'writePermission', label: 'Проверка прав на запись файлов', reason: 'Установщик не имеет прав на запись файлов.' },
                    { code: 'pdoLibrary', label: 'PDO PHP Расширение' },
                    { code: 'mbstringLibrary', label: 'Mbstring PHP Расширение' },
                    { code: 'fileinfoLibrary', label: 'Fileinfo PHP Расширение' },
                    { code: 'sslLibrary', label: 'OpenSSL PHP Расширение' },
                    { code: 'zipLibrary', label: 'ZipArchive PHP Библиотека' },
                    { code: 'gdLibrary', label: 'GD PHP Библиотека' }
                ]

                /*
                 * Config Page
                 */
                Installer.Pages.configForm.title = 'Настройки'
                Installer.Pages.configForm.nextButton = 'Продолжить'

                Installer.Pages.configForm.sections = [
                    { code: 'license', label: 'Лицензия', category: 'Основные', handler: 'onValidateLicense', partial: 'config/license' },
                    { code: 'database', label: 'База данных', category: 'Основные', handler: 'onValidateDatabase', partial: 'config/database' },
                    { code: 'admin', label: 'Администратор', category: 'Основные', handler: 'onValidateAdminAccount', partial: 'config/admin' },
                    { code: 'advanced', label: 'Дополнительные', category: 'Дополнительные', handler: 'onValidateAdvancedConfig', partial: 'config/advanced' }
                ]

                /*
                 * Starter Page
                 */
                Installer.Pages.starterForm.title = 'Начало работы'

                /*
                 * Themes Page
                 */
                Installer.Pages.themesForm.title = 'Начать с темы'

                /*
                 * Project Page
                 */
                Installer.Pages.projectForm.title = 'Детали проекта'
                Installer.Pages.projectForm.nextButton = 'Установить!'

                Installer.Pages.projectForm.sections = [
                    { code: 'project', label: 'Проект', partial: 'project/project' },
                    { code: 'plugins', label: 'Плагины', partial: 'project/plugins' },
                    { code: 'themes', label: 'Темы', partial: 'project/themes' }
                ]

                /*
                 * Progress Page
                 */
                Installer.Pages.installProgress.title = 'Процесс установки...'
                Installer.Pages.installProgress.steps = [
                    { code: 'getMetaData', label: 'Запрос информации о пакете' },
                    { code: 'prepareInstallation', label: 'Подготовка файлов приложения' },
                    { code: 'downloadCore', label: 'Скачивание файлов приложения' },
                    { code: 'checkIfArchiveIsValid', label: 'Проверка загруженных файлов приложения' },
                    { code: 'extractCore', label: 'Распаковка файлов приложения' },
                    { code: 'createAdmin', label: 'Создание администратора' },
                    { code: 'finishInstall', label: 'Завершение установки' }
                ]

                /*
                 * Final Pages
                 */
                Installer.Pages.installComplete.title = 'Поздравляем!'

            </script>

        <?php endif ?>

    </body>
</html>
